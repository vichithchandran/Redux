import Footer from "./components/Footer";
import Header from "./components/Header";

function App() {
  return (
    <>
      <Header />
      <main>
        <div className="bag-page">
          <div className="bag-items-container"></div>
          <div className="bag-summary"></div>
        </div>
      </main>
      <Footer />
      <script src="../data/items.js"></script>
      <script src="../scripts/index.js"></script>
      <script src="../scripts/bag.js"></script>
    </>
  );
}

export default App;
