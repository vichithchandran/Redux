import React from "react";
import Header from "./Header";
import Footer from "./Footer";

function bag() {
  return (
    <div>
      <Header />
      <main>
        <div className="bag-page">
          <div className="bag-items-container"></div>
          <div className="bag-summary"></div>
        </div>
      </main>
      <Footer />
      <script src="../data/items.js"></script>
      <script src="../scripts/index.js"></script>
      <script src="../scripts/bag.js"></script>
    </div>
  );
}

export default bag;
